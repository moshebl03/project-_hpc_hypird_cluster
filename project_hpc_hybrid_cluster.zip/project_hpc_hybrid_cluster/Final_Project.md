# Mini-HPC and Hybrid HPC-Big Data Clusters Project

## Introduction

This project focused on designing and deploying both a traditional High-Performance Computing (HPC) cluster and a hybrid HPC-Big Data cluster using virtual machines. The primary objectives were to:

- Set up a 3-node cluster (1 master, 2 workers) for distributed machine learning (ML) tasks.
- Implement distributed ML with MPI and mpi4py.
- Build a Docker Swarm-based Spark cluster for scalable big data analytics.
- Run and evaluate distributed ML models on both standard datasets (MNIST) and real-world bioinformatics gene expression data.

## Methodology

**Cluster Setup**

- Deployed three Ubuntu 24.04 VMs (1 master, 2 workers) on VirtualBox.
- Configured networking and enabled passwordless SSH between nodes for seamless communication, verified by logging into each worker from the master node.
- Documented all setup steps and issues encountered.

**Task 1: Mini-HPC Cluster with MPI**

- Installed OpenMPI and mpi4py on all nodes.
- Created a hostfile listing all cluster nodes.
- Ran distributed ML training on the MNIST dataset using a custom Python script (`distributed_mnist.py`), distributing data and computation across all nodes.

**Task 2: Hybrid HPC + Big Data Cluster with Spark**

- Initialized Docker Swarm across all three VMs.
- Deployed Apache Spark in cluster mode using a Docker Compose YAML file.
- Verified Spark cluster status and worker registration via the Spark Web UI.
- Ran distributed ML jobs (e.g., gene expression analysis) using PySpark on real bioinformatics datasets.

## Results

**Task 1: Distributed MNIST ML (MPI)**

- Each process trained on a balanced subset of the MNIST dataset:
  - Rank 0: 240 samples
  - Rank 1: 240 samples
  - Rank 2: 239 samples
  - Rank 3: 239 samples
  - Rank 4: 239 samples
  - Rank 5: 239 samples
- Combined Accuracy: **0.942**
- Mean Training Time: **0.044s**
- Total Execution Time: **0.073s**

**Task 2: Spark Cluster (PySpark ML)**

- Spark cluster successfully launched with 2 worker nodes (each with 2 cores, 2GB RAM).
- Workers registered and visible in the Spark Web UI, confirming proper setup.
- Cluster ready for distributed ML tasks on bioinformatics gene expression data.

## Conclusion

Through this project, we gained practical experience in:

- Setting up and configuring both traditional HPC and modern Big Data clusters.
- Implementing distributed machine learning workflows using MPI and Spark.
- Managing real-world bioinformatics data in a scalable, distributed environment.

**Key learnings include:**

- The importance of network and SSH configuration for cluster communication.
- How MPI enables parallelism for scientific computing tasks.
- The flexibility of Spark for large-scale data processing and its integration with Docker Swarm.
- Practical challenges in distributed ML, including data partitioning and resource monitoring.

This project provided a comprehensive foundation in distributed computing and its applications in bioinformatics and machine learning.